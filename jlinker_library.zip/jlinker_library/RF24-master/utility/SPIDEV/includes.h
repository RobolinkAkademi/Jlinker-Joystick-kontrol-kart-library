  
#ifndef __RF24_INCLUDES_H__
#define __RF24_INCLUDES_H__

#define RF24_SPIDEV
  #include "SPIDEV/RF24_arch_config.h"
  #include "SPIDEV/interrupt.h"
#endif
